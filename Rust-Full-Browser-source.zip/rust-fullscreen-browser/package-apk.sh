#!/usr/bin/env bash
# Standalone Android packager: no Gradle dependency downloads.
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
tools="$ANDROID_HOME/build-tools/35.0.0"
platform="$ANDROID_HOME/platforms/android-35/android.jar"
for command_name in javac jar java keytool python3; do command -v "$command_name" >/dev/null; done
[[ -f app/src/main/jniLibs/arm64-v8a/libbrowser_core.so ]] || { echo 'Build the Rust ARM64 library first (see README).'; exit 1; }
work_dir="$(mktemp -d)"
trap 'rm -rf "$work_dir"' EXIT
mkdir -p "$work_dir/classes" "$work_dir/dex" output
javac -source 17 -target 17 -classpath "$platform" -d "$work_dir/classes" app/src/main/java/au/ian/fullbrowser/MainActivity.java
jar cf "$work_dir/classes.jar" -C "$work_dir/classes" .
"$tools/d8" --lib "$platform" --min-api 30 --output "$work_dir/dex" "$work_dir/classes.jar"
python3 - "$work_dir" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=Path('app/src/main/AndroidManifest.xml').read_text()
s=s.replace('<manifest ', '<manifest package="au.ian.fullbrowser" android:versionCode="1" android:versionName="1.0" ',1)
(p/'AndroidManifest.xml').write_text(s)
PY
"$tools/aapt2" link -I "$platform" --manifest "$work_dir/AndroidManifest.xml" --min-sdk-version 30 --target-sdk-version 35 -o "$work_dir/base.apk"
python3 - "$work_dir" <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
import sys
p=Path(sys.argv[1])
with ZipFile(p/'base.apk','a') as z:
    for f in (p/'dex').glob('*.dex'): z.write(f, f.name, compress_type=ZIP_DEFLATED)
    z.write('app/src/main/jniLibs/arm64-v8a/libbrowser_core.so', 'lib/arm64-v8a/libbrowser_core.so', compress_type=ZIP_STORED)
PY
"$tools/zipalign" -P 16 -f 4 "$work_dir/base.apk" "$work_dir/aligned.apk"
# Standard local development key. Keep it private to preserve update identity.
key_path="${BROWSER_KEYSTORE:-$HOME/.android/debug.keystore}"
mkdir -p "$(dirname "$key_path")"
if [[ ! -f "$key_path" ]]; then
    keytool -genkeypair -keystore "$key_path" -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Android Debug,O=Android,C=US'
fi
"$tools/apksigner" sign --ks "$key_path" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out output/Rust-Full-Browser.apk "$work_dir/aligned.apk"
"$tools/apksigner" verify --verbose output/Rust-Full-Browser.apk
"$tools/zipalign" -c -P 16 4 output/Rust-Full-Browser.apk
echo "APK: $PWD/output/Rust-Full-Browser.apk"
