# Rust Browser A52 Pro for Android

Android 11+ / 32-bit ARM and ARM64. Rust address/search handling through JNI, Java native Android UI and Android System WebView rendering. This is not CEF and is not an all-Rust application.

Starts in immersive full-screen mode. Tap the bottom-right menu to reveal the address/search box, Back, Next, Reload, Go and Full controls. Go hides the controls again. Android edge swipes temporarily reveal system navigation. Touch scrolling, pinch zoom, rotation and HTML video full-screen are implemented. Back exits video, hides controls, navigates history, then exits. Display cutouts and keyboard insets are respected.

Only HTTPS browsing is enabled. JavaScript and cookies are enabled; no JavaScript-to-native bridge is exposed. Certificate errors are not bypassed. No tabs, download manager, upload picker, camera/microphone permissions or DRM guarantee. This is a small demonstration browser, not a complete Chrome replacement.

## Build on Linux x86_64
Install JDK 17, stable Rust with rustup and the Android command-line tools. Set ANDROID_HOME. In SDK Manager install platforms;android-35, build-tools;35.0.0 and ndk;28.0.13004108. Run:

```sh
bash build-apk.sh
```

The script packages the APK directly with Android SDK tools; Gradle files are also provided for Android Studio. The result is output/Rust-Browser-A52-Pro.apk, a development-signed APK for personal installation. Keep the same debug signing key for future updates. The official Linux Android NDK is intended for x86_64 computers; this script is not a direct Termux/ARM64 build script.

## Build using GitHub from a phone
Create a repository and upload the contents of this folder, retaining .github/workflows/android.yml. Go to Actions, Build Android APK, Run workflow. After success download Rust-Full-Browser-APK from Artifacts, unzip it and open the APK on Android. GitHub may charge for Actions usage according to your account.

## Install
Open the APK on your phone and allow installation from that browser/file manager if Android prompts. Requires Android 11 or newer, ARM (32-bit or 64-bit), and working Android System WebView. No Play Store publishing is included. A device test remains necessary for rendering, navigation, keyboard, rotation and video behaviour.

## References
https://developer.android.com/develop/ui/views/layout/immersive
https://developer.android.com/reference/android/webkit/WebView
https://docs.rs/jni/0.21.1/jni/

## A52 Pro variant
ZTE lists the Australian A52 Pro as Android 13 Go Edition with a Unisoc SC9863A processor: https://ztemobiles.com.au/zte-a52-pro/
This APK includes armeabi-v7a and arm64-v8a so Android can choose either supported ABI. It retains full-screen mode and touch controls. Device runtime compatibility has not been tested on a physical A52 Pro.
This variant uses application ID au.ian.fullbrowser.a52 and installs separately from the earlier Rust Full Browser. It does not migrate cookies or history.

## Build validation
ARMv7 Rust compilation and Android Java/DEX compilation succeeded. APK signature and ZIP alignment checks passed. The APK contains both armeabi-v7a and arm64-v8a native libraries. No physical device or emulator runtime test performed.
