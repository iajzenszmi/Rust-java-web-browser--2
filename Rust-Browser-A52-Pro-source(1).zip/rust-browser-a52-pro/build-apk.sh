#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/28.0.13004108"
for tool in cargo rustup javac; do command -v "$tool" >/dev/null || { echo "Missing $tool"; exit 1; }; done
if [[ ! -d "$ANDROID_NDK_HOME" ]]; then echo 'Install NDK 28.0.13004108 using SDK Manager'; exit 1; fi
rustup target add aarch64-linux-android armv7-linux-androideabi
cargo install cargo-ndk --version 3.5.4 --locked
(cd native && cargo test && cargo ndk -t arm64-v8a -t armeabi-v7a -p 30 -o ../app/src/main/jniLibs build --release)
bash package-apk.sh
