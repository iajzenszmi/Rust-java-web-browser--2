package au.ian.fullbrowser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;

public final class MainActivity extends Activity {
    static { System.loadLibrary("browser_core"); }
    private static native String resolveAddress(String input);
    private WebView web;
    private LinearLayout controls;
    private EditText address;
    private FrameLayout root;
    private View customVideo;
    private WebChromeClient.CustomViewCallback videoCallback;
    private Button menu;
    private boolean full = true;
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setDecorFitsSystemWindows(false);
        root = new FrameLayout(this);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setBackgroundColor(Color.WHITE);
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextSize(16);
        address.setHint("HTTPS address or search");
        address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        controls.addView(address, new LinearLayout.LayoutParams(-1, dp(52)));
        LinearLayout buttons = new LinearLayout(this);
        addButton(buttons, "Back", () -> { if(web.canGoBack()) web.goBack(); });
        addButton(buttons, "Next", () -> { if(web.canGoForward()) web.goForward(); });
        addButton(buttons, "Reload", () -> web.reload());
        addButton(buttons, "Go", this::navigate);
        addButton(buttons, "Full", () -> setFull(true));
        controls.addView(buttons);
        column.addView(controls);
        web = new WebView(this);
        column.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(column, new FrameLayout.LayoutParams(-1, -1));
        menu = new Button(this);
        menu.setText("☰");
        menu.setContentDescription("Show browser controls");
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(56), dp(48), Gravity.BOTTOM | Gravity.END);
        mp.setMargins(0,0,dp(8),dp(8));
        root.addView(menu, mp);
        menu.setOnClickListener(v -> setFull(false));
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets cut = insets.getInsets(WindowInsets.Type.displayCutout());
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
            v.setPadding(Math.max(cut.left,bars.left), Math.max(cut.top,bars.top),
                Math.max(cut.right,bars.right), Math.max(ime.bottom,Math.max(cut.bottom,bars.bottom)));
            return insets;
        });
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String scheme = req.getUrl().getScheme();
                if ("https".equalsIgnoreCase(scheme)) return false;
                if(req.isForMainFrame()) Toast.makeText(MainActivity.this, "Only HTTPS pages are supported", Toast.LENGTH_SHORT).show();
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                if (!address.hasFocus()) address.setText(url);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (!address.hasFocus()) address.setText(url);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                if(customVideo != null) { cb.onCustomViewHidden(); return; }
                customVideo=view; videoCallback=cb;
                root.addView(view, new FrameLayout.LayoutParams(-1,-1));
                menu.setVisibility(View.GONE);
                hideBars();
            }
            @Override public void onHideCustomView() { closeVideo(); }
        });
        address.setOnEditorActionListener((v, action, event) -> { navigate(); return true; });
        if(saved == null || web.restoreState(saved) == null) web.loadUrl("https://www.google.com/");
        setFull(saved == null || saved.getBoolean("full", true));
    }
    private void addButton(LinearLayout row, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setPadding(0,0,0,0);
        row.addView(b, new LinearLayout.LayoutParams(0,dp(48),1));
        b.setOnClickListener(v -> action.run());
    }
    private void navigate() {
        String url=resolveAddress(address.getText().toString());
        if(url == null) { Toast.makeText(this,"Cannot open address",Toast.LENGTH_SHORT).show(); return; }
        address.clearFocus(); web.requestFocus();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);
        web.loadUrl(url); setFull(true);
    }
    private void hideBars() {
        WindowInsetsController c = getWindow().getInsetsController();
        if(c != null) {
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            c.hide(WindowInsets.Type.systemBars());
        }
    }
    private void setFull(boolean value) {
        full=value;
        controls.setVisibility(value ? View.GONE : View.VISIBLE);
        menu.setVisibility(value && customVideo == null ? View.VISIBLE : View.GONE);
        if(value) {
            address.clearFocus(); web.requestFocus();
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);
            hideBars();
        } else {
            getWindow().getInsetsController().show(WindowInsets.Type.systemBars());
            address.setText(web.getUrl());
        }
    }
    private void closeVideo() {
        if(customVideo == null) return;
        root.removeView(customVideo); customVideo=null;
        WebChromeClient.CustomViewCallback cb=videoCallback; videoCallback=null;
        if(cb != null) cb.onCustomViewHidden();
        setFull(full);
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus && (full || customVideo != null)) hideBars();
    }
    @Override public void onBackPressed() {
        if(customVideo != null) closeVideo();
        else if(!full) setFull(true);
        else if(web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        web.saveState(out); out.putBoolean("full",full); super.onSaveInstanceState(out);
    }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if(web != null) web.onResume(); }
    @Override protected void onDestroy() { closeVideo(); web.destroy(); super.onDestroy(); }
}
