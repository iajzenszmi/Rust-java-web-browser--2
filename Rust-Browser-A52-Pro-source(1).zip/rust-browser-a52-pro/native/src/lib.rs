use jni::{JNIEnv, objects::{JClass, JString}, sys::jstring};

fn destination(input: &str) -> String {
    let text = input.trim();
    if text.is_empty() { return "https://www.google.com/".into(); }
    let lower = text.to_ascii_lowercase();
    if lower.starts_with("https://") {
        if let Ok(url) = url::Url::parse(text) {
            if url.host_str().is_some() { return url.into(); }
        }
    } else if !text.contains(char::is_whitespace) && !text.contains("://") && text.contains('.') {
        if let Ok(url) = url::Url::parse(&format!("https://{text}")) {
            if url.host_str().is_some() && url.username().is_empty() && url.password().is_none() {
                return url.into();
            }
        }
    }
    let mut url = url::Url::parse("https://www.google.com/search").unwrap();
    url.query_pairs_mut().append_pair("q", text);
    url.into()
}

#[no_mangle]
pub extern "system" fn Java_au_ian_fullbrowser_MainActivity_resolveAddress(
    mut env: JNIEnv, _class: JClass, input: JString,
) -> jstring {
    let text: String = match env.get_string(&input) {
        Ok(s) => s.into(), Err(_) => return std::ptr::null_mut(),
    };
    env.new_string(destination(&text)).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn destinations() {
        assert_eq!(destination(" example.com "), "https://example.com/");
        assert_eq!(destination("https://example.com/a?x=1"), "https://example.com/a?x=1");
        assert_eq!(destination("weather Melbourne"), "https://www.google.com/search?q=weather+Melbourne");
        assert!(destination("javascript:alert(1)").starts_with("https://www.google.com/search?"));
        assert!(destination("file:///etc/passwd").starts_with("https://www.google.com/search?"));
        assert!(destination("name@example.com").starts_with("https://www.google.com/search?"));
    }
}
